<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
            <?php
            session_start();
            include_once '../Utilities/connection.php';
            if(mysqli_query($con,"delete from school_image where image_id like '".$_GET['key']."'")){
            if($result=  mysqli_query($con, "select image,image_id  from school_image where image_id like 'AP%'")){
    //fetch one and one row
            $c=0;
            $arr=array();
    while($row= mysqli_fetch_assoc($result)){
        $arr[$c]=$row['image_id'];
        $c++;        
        echo "
  <!-- Trigger the modal with a button -->
  <button type=button data-toggle=modal data-target=#".$c."><img src='".$row["image"]."' width=70 height=70></button>
&nbsp&nbsp&nbsp
  <!-- Modal -->
    <div class='modal fade' id=".$c." role=dialog>
    <div class='modal-dialog modal-lg'>
      <div class=modal-content>
        <div class=modal-header>
          <button type=button class=close data-dismiss=modal>&times;</button>
          <h4 class=modal-title>".$row['image_id']."</h4>
        </div>
        <div class=modal-body align=center>
          <p><img src='".$row["image"]."' width=98% height=98%></p>
        </div>
        <div class=modal-footer>
        <input type=text value=".$row['image_id']." id=imgid name=imgid hidden>
        <button type=button class='btn btn-default' onclick=loadXMLDoc(\"".$row['image_id']."\",\"".$row['image']."\")  data-dismiss=modal>Delete</button>&nbsp&nbsp&nbsp
          <button type=button class='btn btn-default' data-dismiss=modal>Close</button>
        </div>
      </div>
    </div>
   </div>    
";       
    }
    //Free result set    
    mysqli_free_result($result);
}
                echo "<font color=green>Image(".$_GET['key'].") succesfully deleted..</font>"; 
                unlink($_GET['loc']);
            }  else {
                echo "<font color=red>Could not delete</font>";
}             
        // put your code here
        ?>
        <script>
            confirm("Do u really wanna delete");
        </script>
    </body>
</html>
