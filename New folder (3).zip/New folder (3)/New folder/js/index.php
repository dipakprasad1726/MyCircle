<!doctype html>
<?php 
include 'connection.php';
?>
<html>

    <head lang="en">
	<meta charset="utf-8">
	<title>Easy Ajax Image Upload with jQuery and PHP - codingcage.com</title>
    <script src="jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="redir.js" type="text/javascript"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
 
	<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
        <script>
            $(document).ready(function(){
                done();
            });
            function done(){
                setTimeout(function(){
                    update();
                    done();
                })
            }
        </script>
        

    </head>
<body>
<div class="container">
	<h1><a href="http://www.codingcage.com/2015/12/easy-ajax-image-upload-with-jquery-php.html" target="_blank">Easy Ajax Image Upload with jQuery</a></h1>
	<hr>   
	<form id="form" action="ajaxupload.php" method="post" enctype="multipart/form-data">
		<input id="uploadImage" type="file" accept="image/*" name="image" />
		<input id="button" type="submit" value="Upload">
	<div id="preview"> <?php
    
        if($result=  mysqli_query($con, "select image from school_image where image_id like 'AP%'")){
    //fetch one and one row
    while($row= mysqli_fetch_assoc($result)){
        
        echo "
<div class=container>
  <h2>Large Modal</h2>
  <!-- Trigger the modal with a button -->
  <button type=button class='btn btn-info btn-lg' data-toggle=modal data-target=#".$row["image"]."><img src='".$row["image"]."' width=100 height=100></button>
&nbsp&nbsp&nbsp
  <!-- Modal -->
          
";
    }
    //Free result set
    mysqli_free_result($result);
}

?></div>
                
        </form>
        
    <div id="err"></div>
    
     
	<hr>
        <div class='modal fade' id=".$row["image"]." role=dialog>
    <div class='modal-dialog modal-lg'>
      <div class=modal-content>
        <div class=modal-header>
          <button type=button class=close data-dismiss=modal>&times;</button>
          <h4 class=modal-title>Modal Header</h4>
        </div>
        <div class=modal-body>
          <p><img src='".$row["image"]."' width=70% height=70%></p>
        </div>
        <div class=modal-footer>
          <button type=button class='btn btn-default' data-dismiss=modal>Close</button>
        </div>
      </div>
    </div>
  </div>
</div>    
	<p><a href="http://www.codingcage.com" target="_blank">www.codingcage.com</a></p>
</div>
</body>
</html>