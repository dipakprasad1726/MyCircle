<?php
include 'connection.php';
session_start();

$_SESSION['deleteImageId']='NULL';
?>
<script>
function loadXMLDoc(data,imgadd)
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject('Microsoft.XMLHTTP');
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById('preview').innerHTML=xmlhttp.responseText;
    }
  }  
  var x;
if(confirm('IMAGE ID : '+data)==true){
    xmlhttp.open('GET','deleteImage.php?key='+data+'&loc='+imgadd,true);
xmlhttp.send();
}else{
    x="<br><br><br><br>Delete attempt canceled : "+data;
    document.getElementById("prev2").innerHTML=x;
}


}
</script>
<?php

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions
$path = 'uploads/'; // upload directory

//require 'Utilities/connection.php';

if(isset($_FILES['image']))
{
	$img = $_FILES['image']['name'];
	$tmp = $_FILES['image']['tmp_name'];
		
	// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
	
	// can upload same image using rand function
	$final_image = "AP".rand(1000,1000000).".jpg";
	// check's valid format
	if(in_array($ext, $valid_extensions)){					
		$path = $path.$final_image;			
		if(move_uploaded_file($tmp,$path)){
			
                        if(!mysqli_query($con, "insert into school_image(image_id,image,school_code,image_description) values
                            ('AP16".rand(1000,1000000)."','$path','SCH1001','authorised person image')")){
                            die('Error: ' . mysqli_error($con));
                        }                          
                }
	}else{	echo 'invalid';	}
}
//unlink("uploads/AP408185.jpg");
$result=  mysqli_query($con, "select image,image_id from school_image where image_id like 'AP%'");
 if($result){
    //fetch one and one row
    $c=0;
    $arr=array();
     while($row= mysqli_fetch_assoc($result)){
        $arr[$c]=$row['image_id'];
         $c++;
        echo "

  <!-- Trigger the modal with a button -->
  <button type=button data-toggle=modal data-target=#".$c."><img src='".$row["image"]."' width=70 height=70></button>
&nbsp&nbsp&nbsp
  <!-- Modal -->
    <div class='modal fade' id=".$c." role=dialog>
    <div class='modal-dialog modal-lg'>
      <div class=modal-content>
        <div class=modal-header>
          <button type=button class=close data-dismiss=modal>&times;</button>
          <h4 class=modal-title>".$row['image_id']."</h4>
        </div>
        <div class=modal-body align=center>
          <p><img src='".$row["image"]."' width=98% height=98%></p>
        </div>
        <div class=modal-footer>
        <input type=text value=".$row['image_id']." id=imgid name=imgid hidden>
        <button type=button class='btn btn-default' onclick=loadXMLDoc(\"".$row['image_id']."\",\"".$row['image']."\")  data-dismiss=modal>Delete</button>&nbsp&nbsp&nbsp
          <button type=button class='btn btn-default' data-dismiss=modal>Close</button>
        </div>
      </div>
    </div>
   </div>    
"; 
       
    }
    
    //Free result set
    mysqli_free_result($result);
}
mysqli_close($con);
?>