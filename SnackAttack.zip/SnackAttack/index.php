<html>
<head>
<style>
body{
background-image:url(assets/sky.png);
background-repeat: no-repeat;
background-size: cover;
}
</style>
</head>
<body>
<center>
<img src="assets/game.png"><br>
<img src="assets/logoSA.png"><br>
<h2>
taKe a PHOtO Of your mouth to<br>
jOiN tHe SNaCK attacCK GaMe<br>
NOW aND WiN eXcitiNG PRiZeS!
</h2>
<a href="page2.php"><img src="assets/start.png"></a>
</center>
</body>
</html>
