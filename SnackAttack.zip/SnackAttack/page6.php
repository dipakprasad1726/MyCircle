<html>
<head>
<style>
body{
background-image:url(assets/sky.png);
background-repeat: no-repeat;
background-size: cover;
}
</style>
</head>
<body>
<center>
<img src="assets/logoSA.png" width=170px height=250px><br><br>
<img src="assets/mouth.png" width=200px height=170px><br>
<h2>
PeRFeCt! StaRt PlaYiNG NOW</h2><br>
<a href="game.html"><img src="assets/ok.png"></a>
</center>
</body>
</html>
