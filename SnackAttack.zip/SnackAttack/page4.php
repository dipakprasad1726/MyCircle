<html>
<head>
<style>
body{
background-image:url(assets/sky.png);
background-repeat: no-repeat;
background-size: cover;
}
</style>
</head>
<body>
<center>
<img src="assets/logoSA.png" width=170px height=250px><br><br>
<img src="assets/mouthcls.png" width=200px height=170px><br>
<h2>
Great! NoW taKe a PHOtO Of your<br>
 MoUtH WiDe OPeN</h2><br>
<a href="page5.php"><img src="assets/camera.png"></a>
</center>
</body>
</html>
