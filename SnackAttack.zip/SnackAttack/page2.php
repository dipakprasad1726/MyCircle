<html>
<head>
<style>
body{
background-image:url(assets/sky.png);
background-repeat: no-repeat;
background-size: cover;
}
</style>
</head>
<body>
<center>
<img src="assets/logoSA.png" width=170px height=250px><br><br>
<img src="assets/mouthclose.png" width=200px height=80px><br>
<h2>
TaKe a PHOtO Of your mouth<br>
ClOSeD NOW</h2><br>
<a href="page3.php"><img src="assets/camera.png"></a>
</center>
</body>
</html>
